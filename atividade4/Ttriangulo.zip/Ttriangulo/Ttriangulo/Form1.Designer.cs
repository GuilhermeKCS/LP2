﻿namespace Ttriangulo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblA = new System.Windows.Forms.Label();
            this.lblB = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.txtLadoA = new System.Windows.Forms.TextBox();
            this.txtLadoB = new System.Windows.Forms.TextBox();
            this.txtLadoC = new System.Windows.Forms.TextBox();
            this.btnValidar = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblA
            // 
            this.lblA.AutoSize = true;
            this.lblA.Location = new System.Drawing.Point(198, 138);
            this.lblA.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(65, 24);
            this.lblA.TabIndex = 0;
            this.lblA.Text = "LadoA";
            this.lblA.Click += new System.EventHandler(this.label1_Click);
            // 
            // lblB
            // 
            this.lblB.AutoSize = true;
            this.lblB.Location = new System.Drawing.Point(196, 203);
            this.lblB.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(64, 24);
            this.lblB.TabIndex = 1;
            this.lblB.Text = "LadoB";
            // 
            // lblC
            // 
            this.lblC.AutoSize = true;
            this.lblC.Location = new System.Drawing.Point(198, 281);
            this.lblC.Margin = new System.Windows.Forms.Padding(6, 0, 6, 0);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(65, 24);
            this.lblC.TabIndex = 2;
            this.lblC.Text = "LadoC";
            // 
            // txtLadoA
            // 
            this.txtLadoA.Location = new System.Drawing.Point(321, 138);
            this.txtLadoA.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtLadoA.Name = "txtLadoA";
            this.txtLadoA.Size = new System.Drawing.Size(180, 29);
            this.txtLadoA.TabIndex = 3;
            this.txtLadoA.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // txtLadoB
            // 
            this.txtLadoB.Location = new System.Drawing.Point(321, 203);
            this.txtLadoB.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtLadoB.Name = "txtLadoB";
            this.txtLadoB.Size = new System.Drawing.Size(180, 29);
            this.txtLadoB.TabIndex = 4;
            this.txtLadoB.TextChanged += new System.EventHandler(this.txtLadoB_TextChanged);
            // 
            // txtLadoC
            // 
            this.txtLadoC.Location = new System.Drawing.Point(321, 281);
            this.txtLadoC.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.txtLadoC.Name = "txtLadoC";
            this.txtLadoC.Size = new System.Drawing.Size(180, 29);
            this.txtLadoC.TabIndex = 5;
            this.txtLadoC.TextChanged += new System.EventHandler(this.txtLadoC_TextChanged);
            // 
            // btnValidar
            // 
            this.btnValidar.Font = new System.Drawing.Font("MV Boli", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidar.Location = new System.Drawing.Point(559, 357);
            this.btnValidar.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.btnValidar.Name = "btnValidar";
            this.btnValidar.Size = new System.Drawing.Size(269, 109);
            this.btnValidar.TabIndex = 6;
            this.btnValidar.Text = "Verificar";
            this.btnValidar.UseVisualStyleBackColor = true;
            this.btnValidar.Click += new System.EventHandler(this.btnValidar_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpar.Location = new System.Drawing.Point(912, 357);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(214, 109);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(11F, 24F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1924, 1061);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnValidar);
            this.Controls.Add(this.txtLadoC);
            this.Controls.Add(this.txtLadoB);
            this.Controls.Add(this.txtLadoA);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.lblA);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.Name = "Form1";
            this.Text = "Ttriangulo";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.TextBox txtLadoA;
        private System.Windows.Forms.TextBox txtLadoB;
        private System.Windows.Forms.TextBox txtLadoC;
        private System.Windows.Forms.Button btnValidar;
        private System.Windows.Forms.Button btnLimpar;
    }
}

