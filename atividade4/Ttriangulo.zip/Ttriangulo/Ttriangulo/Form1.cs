﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ttriangulo
{
    public partial class Form1 : Form
    {
        double txtA, txtB, txtC;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out txtA))
            {
                MessageBox.Show("Número inválido");
                //txtLadoA.Focus();
            }
        }

        private void txtLadoB_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out txtB))
            {
                MessageBox.Show("Número inválido");
                //txtLadoB.Focus();
            }
        }

        private void txtLadoC_TextChanged(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out txtC))
            {
                MessageBox.Show("Número inválido");
                //txtLadoC.Focus();
            }
        }

        private void btnValidar_Validating(object sender, CancelEventArgs e)
        {

        }

        private void btnValidar_Click(object sender, EventArgs e)
        {
             if (!double.TryParse(txtLadoB.Text, out txtB))
            
                MessageBox.Show("Número inválido");
             else if (!double.TryParse(txtLadoB.Text, out txtB))

                 MessageBox.Show("Número inválido");

             else if (!double.TryParse(txtLadoC.Text, out txtC))

                 MessageBox.Show("Número inválido");

             else
             {
                 if ((txtA < (txtB + txtC)) &&
                 (txtA > Math.Abs(txtB - txtC)) &&
                 (txtB < (txtA + txtC)) &&
                 (txtB > Math.Abs(txtA - txtC)) &&
                  (txtC < (txtA + txtB)) &&
                 (txtC > Math.Abs(txtA - txtB)))

                     if ((txtA == txtB) && (txtB == txtC))
                         MessageBox.Show("Equilátero");
                     else
                         if ((txtA == txtB) || (txtA == txtC) || (txtB == txtC))
                             MessageBox.Show("isósceles");
                         else
                             MessageBox.Show("escaleno");
             }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }
        }
    }

