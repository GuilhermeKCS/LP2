﻿namespace PAtividade8
{
    partial class frmExercicio1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtPares = new System.Windows.Forms.TextBox();
            this.txtLetrasR = new System.Windows.Forms.TextBox();
            this.txtBrancos = new System.Windows.Forms.TextBox();
            this.btnPares = new System.Windows.Forms.Button();
            this.btnLetrasR = new System.Windows.Forms.Button();
            this.btnBrancos = new System.Windows.Forms.Button();
            this.labelQuantidades = new System.Windows.Forms.Label();
            this.rtfFrase = new System.Windows.Forms.RichTextBox();
            this.SuspendLayout();
            // 
            // txtPares
            // 
            this.txtPares.Enabled = false;
            this.txtPares.Location = new System.Drawing.Point(198, 240);
            this.txtPares.Name = "txtPares";
            this.txtPares.Size = new System.Drawing.Size(110, 20);
            this.txtPares.TabIndex = 14;
            // 
            // txtLetrasR
            // 
            this.txtLetrasR.Enabled = false;
            this.txtLetrasR.Location = new System.Drawing.Point(198, 149);
            this.txtLetrasR.Name = "txtLetrasR";
            this.txtLetrasR.Size = new System.Drawing.Size(110, 20);
            this.txtLetrasR.TabIndex = 13;
            // 
            // txtBrancos
            // 
            this.txtBrancos.Enabled = false;
            this.txtBrancos.Location = new System.Drawing.Point(198, 78);
            this.txtBrancos.Name = "txtBrancos";
            this.txtBrancos.Size = new System.Drawing.Size(110, 20);
            this.txtBrancos.TabIndex = 12;
            // 
            // btnPares
            // 
            this.btnPares.Location = new System.Drawing.Point(58, 225);
            this.btnPares.Name = "btnPares";
            this.btnPares.Size = new System.Drawing.Size(122, 48);
            this.btnPares.TabIndex = 11;
            this.btnPares.Text = "Pares de Letras";
            this.btnPares.UseVisualStyleBackColor = true;
            this.btnPares.Click += new System.EventHandler(this.btnPares_Click);
            // 
            // btnLetrasR
            // 
            this.btnLetrasR.Location = new System.Drawing.Point(58, 134);
            this.btnLetrasR.Name = "btnLetrasR";
            this.btnLetrasR.Size = new System.Drawing.Size(122, 48);
            this.btnLetrasR.TabIndex = 10;
            this.btnLetrasR.Text = "Letras R";
            this.btnLetrasR.UseVisualStyleBackColor = true;
            this.btnLetrasR.Click += new System.EventHandler(this.btnLetrasR_Click);
            // 
            // btnBrancos
            // 
            this.btnBrancos.Location = new System.Drawing.Point(58, 63);
            this.btnBrancos.Name = "btnBrancos";
            this.btnBrancos.Size = new System.Drawing.Size(122, 48);
            this.btnBrancos.TabIndex = 8;
            this.btnBrancos.Text = "Espaços em Branco";
            this.btnBrancos.UseVisualStyleBackColor = true;
            this.btnBrancos.Click += new System.EventHandler(this.btnBrancos_Click);
            // 
            // labelQuantidades
            // 
            this.labelQuantidades.AutoSize = true;
            this.labelQuantidades.Location = new System.Drawing.Point(55, 28);
            this.labelQuantidades.Name = "labelQuantidades";
            this.labelQuantidades.Size = new System.Drawing.Size(70, 13);
            this.labelQuantidades.TabIndex = 9;
            this.labelQuantidades.Text = "Quantidades:";
            // 
            // rtfFrase
            // 
            this.rtfFrase.Location = new System.Drawing.Point(314, 42);
            this.rtfFrase.Name = "rtfFrase";
            this.rtfFrase.Size = new System.Drawing.Size(214, 246);
            this.rtfFrase.TabIndex = 15;
            this.rtfFrase.Text = "";
            // 
            // frmExercicio1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(558, 486);
            this.Controls.Add(this.rtfFrase);
            this.Controls.Add(this.txtPares);
            this.Controls.Add(this.txtLetrasR);
            this.Controls.Add(this.txtBrancos);
            this.Controls.Add(this.btnPares);
            this.Controls.Add(this.btnLetrasR);
            this.Controls.Add(this.btnBrancos);
            this.Controls.Add(this.labelQuantidades);
            this.Name = "frmExercicio1";
            this.Text = "frmExercicio1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtPares;
        private System.Windows.Forms.TextBox txtLetrasR;
        private System.Windows.Forms.TextBox txtBrancos;
        private System.Windows.Forms.Button btnPares;
        private System.Windows.Forms.Button btnLetrasR;
        private System.Windows.Forms.Button btnBrancos;
        private System.Windows.Forms.Label labelQuantidades;
        private System.Windows.Forms.RichTextBox rtfFrase;
    }
}