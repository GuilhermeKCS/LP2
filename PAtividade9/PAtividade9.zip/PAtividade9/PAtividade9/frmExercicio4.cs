﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PAtividade9
{
    public partial class frmExercicio4 : Form
    {
        public frmExercicio4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Guilherme", "Matso", "Lucas", "Carlos Tijolo", "GBzap", "Rocha", "Monitor", "Denilce", "Munari" };


            int I, Total = 0;
            int N = Alunos.Length;

            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }

            txtResposta.Text = Total.ToString();
        }
    }
}
