﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        double imc, peso, altura;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Clear();
            mskbxPeso.Clear();
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxAltura.Text, out altura))
            {
                MessageBox.Show("Digite uma altura valida");
                mskbxAltura.Focus();
            }
        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(mskbxPeso.Text, out peso))
            {
                MessageBox.Show("Digite um peso valido");
                mskbxPeso.Focus();
            }
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if(double.TryParse(mskbxAltura.Text,out altura) && double.TryParse(mskbxPeso.Text, out peso))
            {
                //imc = peso / Math.Pow(altura, 2);
                imc = peso / (altura * altura);
                imc = Math.Round(imc, 1);

                if (imc < 18.5)
                    MessageBox.Show("seu imc é "+ imc.ToString() + " você está abaixo do peso ideal");
                else
                    if (imc < 24.9)
                        MessageBox.Show("seu imc é " + imc.ToString() + " você está no peso ideal");
                    else
                        if (imc <29.9)
                            MessageBox.Show("seu imc é " + imc.ToString() + " você está acima do peso ideal");
                        else
                            if (imc < 39.9)
                                MessageBox.Show("seu imc é " + imc.ToString() + " você está com obesidade");
                            else
                                MessageBox.Show("seu imc é " + imc.ToString() + " você está com obesidade grave");
            }
               


            
        }
    }
}
