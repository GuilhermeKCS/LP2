﻿namespace PtestMetodos
{
    partial class frmExercicio3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblpalavra1 = new System.Windows.Forms.Label();
            this.lblpalavra2 = new System.Windows.Forms.Label();
            this.txtpalavraum = new System.Windows.Forms.TextBox();
            this.txtpalavradois = new System.Windows.Forms.TextBox();
            this.btnremove = new System.Windows.Forms.Button();
            this.btnremove2 = new System.Windows.Forms.Button();
            this.btninvert = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblpalavra1
            // 
            this.lblpalavra1.AutoSize = true;
            this.lblpalavra1.Location = new System.Drawing.Point(89, 36);
            this.lblpalavra1.Name = "lblpalavra1";
            this.lblpalavra1.Size = new System.Drawing.Size(49, 13);
            this.lblpalavra1.TabIndex = 0;
            this.lblpalavra1.Text = "Palavra1";
            // 
            // lblpalavra2
            // 
            this.lblpalavra2.AutoSize = true;
            this.lblpalavra2.Location = new System.Drawing.Point(89, 63);
            this.lblpalavra2.Name = "lblpalavra2";
            this.lblpalavra2.Size = new System.Drawing.Size(49, 13);
            this.lblpalavra2.TabIndex = 1;
            this.lblpalavra2.Text = "Palavra2";
            // 
            // txtpalavraum
            // 
            this.txtpalavraum.Location = new System.Drawing.Point(158, 33);
            this.txtpalavraum.Name = "txtpalavraum";
            this.txtpalavraum.Size = new System.Drawing.Size(100, 20);
            this.txtpalavraum.TabIndex = 2;
            // 
            // txtpalavradois
            // 
            this.txtpalavradois.Location = new System.Drawing.Point(158, 60);
            this.txtpalavradois.Name = "txtpalavradois";
            this.txtpalavradois.Size = new System.Drawing.Size(100, 20);
            this.txtpalavradois.TabIndex = 3;
            // 
            // btnremove
            // 
            this.btnremove.Location = new System.Drawing.Point(133, 159);
            this.btnremove.Name = "btnremove";
            this.btnremove.Size = new System.Drawing.Size(90, 44);
            this.btnremove.TabIndex = 4;
            this.btnremove.Text = "Remove ocorrencias";
            this.btnremove.UseVisualStyleBackColor = true;
            this.btnremove.Click += new System.EventHandler(this.btnremove_Click);
            // 
            // btnremove2
            // 
            this.btnremove2.Location = new System.Drawing.Point(281, 159);
            this.btnremove2.Name = "btnremove2";
            this.btnremove2.Size = new System.Drawing.Size(124, 44);
            this.btnremove2.TabIndex = 5;
            this.btnremove2.Text = "Remove ocorrencia(replace)";
            this.btnremove2.UseVisualStyleBackColor = true;
            this.btnremove2.Click += new System.EventHandler(this.btnremove2_Click);
            // 
            // btninvert
            // 
            this.btninvert.Location = new System.Drawing.Point(465, 159);
            this.btninvert.Name = "btninvert";
            this.btninvert.Size = new System.Drawing.Size(113, 44);
            this.btninvert.TabIndex = 6;
            this.btninvert.Text = "Inverte(reverse)";
            this.btninvert.UseVisualStyleBackColor = true;
            this.btninvert.Click += new System.EventHandler(this.btninvert_Click);
            // 
            // frmExercicio3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(786, 480);
            this.Controls.Add(this.btninvert);
            this.Controls.Add(this.btnremove2);
            this.Controls.Add(this.btnremove);
            this.Controls.Add(this.txtpalavradois);
            this.Controls.Add(this.txtpalavraum);
            this.Controls.Add(this.lblpalavra2);
            this.Controls.Add(this.lblpalavra1);
            this.Name = "frmExercicio3";
            this.Text = "frmExercicio3";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblpalavra1;
        private System.Windows.Forms.Label lblpalavra2;
        private System.Windows.Forms.TextBox txtpalavraum;
        private System.Windows.Forms.TextBox txtpalavradois;
        private System.Windows.Forms.Button btnremove;
        private System.Windows.Forms.Button btnremove2;
        private System.Windows.Forms.Button btninvert;
    }
}